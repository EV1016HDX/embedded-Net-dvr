# embedded-Net-dvr
Hikivison 
